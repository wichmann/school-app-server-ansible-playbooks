<!--Installed Language Changes Add Loader-->
<div id="overlay_loader">
    <div class="main-spinner">
        <span class="sub-spinner"></span>
    </div>
</div>
<!--Installed Language Changes Add Loader-->